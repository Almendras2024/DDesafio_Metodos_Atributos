proteinas = ["pollo", "vacuno", "carne vegetal" ]
vegetales = ["tomates", "aceitunas", "champiñones"]
masa = ["tradicional", "delgada", ""]